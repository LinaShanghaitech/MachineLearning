clc;
clear;
tic;
X = [0 0 1;2 2 1;2 0 1;3 0 1];
Y = [0;0;1;1];

threshold = 1e-5;
w = [0,0,0]';

theta = sigmod(X * w);
g = X' * (theta - Y);
H_inv = eye(3);
iters = 0;
gg = ones(1,1000000);

while norm(g) > threshold
    w_new = w - H_inv * g;
    theta = sigmod(X * w_new);
    g_new = X' * (theta - Y);
    s = w_new - w;
    y = g_new - g;
    H_inv = (eye(3) - s * y' / (y' * s)) * H_inv * (eye(3) - y * s' / (y' * s)) + s * s' / (y' * s);
    w = w_new;
    g = g_new;
    iters = iters + 1;
    gg(iters) = log(norm(g,2));
end
toc;
pred = sigmod(X * w) > 0.5;
wrong = sum((pred ~= Y));

plot(gg(1:iters));