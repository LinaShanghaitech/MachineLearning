function [ y ] = sigmod( x )
    y = 1 ./ (1 + exp(-x));
end

